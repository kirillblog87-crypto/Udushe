A study reference for lessons, homework and revision, in six tiles: physics (the table of quantities with letters, units and formulas), algebra (powers, fractions, formulas, equations), geometry (bisector, median, signs of equal and similar triangles, areas), Russian (participles and verbal adjectives), literature (short retellings of the 7th grade works) and history (notes on the paragraphs of the Russian history textbook, 16th-17th centuries).

Tap a tile, then a topic. **Назад** or the title goes back. The text is built into the app, so it needs no phone and no network. Formulas are written in plain characters (`^` is a power, `sqrt` a root, `pi` the number π, `rho` the density), because the watch's fonts have no special symbols. The retellings and the history notes are short summaries written for the app, not the textbook's text.

## Requirements

The [patched firmware](/firmware) and the [App Loader](/firmware). Open it from the **Apps** row at the end of the watch's app list (list style, not the waterfall).
