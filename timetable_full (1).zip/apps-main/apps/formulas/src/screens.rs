//! The reference's three screens in the watch's stock LVGL look: the menu (2x3 tiles, one per section), a
//! section's list of topics and a topic (cards with a formula above and its caption under it, or lines of text).
//! Leaving a screen deletes its page with everything on it.
//!
//! Layout notes for the 466x466 round panel: the visible half-width at row `y` is `isqrt(233² - (y-233)²)`; the
//! tiles' outer corners stay inside it (see the tests).

use crate::data::{Body, COUNT, MAX_TOPICS, SECTIONS};
use cmf_wp2_app::lv::*;
use cmf_wp2_app::stock::{self, GREY, ROW_BG, ROW_H, ROW_PRESSED, ROW_W};

/// Font slots besides the system font (slot `stock::FONT`).
pub const F48: u8 = 1;
pub const F18: u8 = 2;
pub const F24: u8 = 3;

// bytes one widget group can take: flush first when fewer are left
const GROUP: usize = 620;
/// Text starts clear of the curved left edge of the panel.
const TEXT_X: i16 = 28;
const TEXT_W: i32 = ROW_W - TEXT_X as i32 - 28;
/// How many characters of the body font (F24) fit a line, counted low on purpose (words wrap early), and the
/// line height: a paragraph gets room for this many lines, so lines never overlap the next paragraph.
const CPL: usize = TEXT_W as usize * 85 / 100 / 13;
const LINE_H: usize = 32;

pub const TILE_W: i32 = 140;
pub const TILE_H: i32 = 108;
pub const TILE_GAP: i32 = 8;
pub const TILE_TOP: i32 = 62;

pub type Flush<'a> = &'a mut dyn FnMut(&mut Batch) -> Result<(), LvError>;

/// Flushes first when the batch could not take `extra` more bytes (a text) and a group of widgets.
fn room(b: &mut Batch, flush: Flush, extra: usize) -> Result<(), LvError> {
    if b.bytes().len() + GROUP + extra > BUF { flush(b) } else { Ok(()) }
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Menu,
    Topics,
    Topic,
}

/// The handles the app reacts to; unused ones are `ROOT` (never an event target).
#[derive(Clone, Copy)]
pub struct Screen {
    pub kind: Kind,
    pub page: Obj,
    /// Menu: a tile per section.
    pub tiles: [Obj; COUNT],
    /// Topics: a row per topic.
    pub rows: [Obj; MAX_TOPICS],
    /// Topics and Topic: the title and the last row, both go back.
    pub back: Obj,
    pub back_row: Obj,
}

const EMPTY: Screen = Screen {
    kind: Kind::Menu,
    page: ROOT,
    tiles: [ROOT; COUNT],
    rows: [ROOT; MAX_TOPICS],
    back: ROOT,
    back_row: ROOT,
};

/// Deletes the current screen: its page with every object and its scroll bar.
pub fn leave(b: &mut Batch, s: &Screen) -> Result<(), LvError> {
    if s.page != ROOT { b.del(s.page) } else { Ok(()) }
}

/// A full-screen page that does not scroll (the menu).
fn plain_page(b: &mut Batch) -> Result<Obj, LvError> {
    let page = b.create(Class::Obj, ROOT)?;
    b.size(page, stock::SCREEN, stock::SCREEN)?;
    for p in [Prop::PadTop, Prop::PadBottom, Prop::PadLeft, Prop::PadRight, Prop::BorderWidth, Prop::BgOpa] {
        b.style(page, p, 0, 0)?;
    }
    b.flags(page, &[], &[Flag::Scrollable])?;
    Ok(page)
}

/// The menu: six square tiles in two columns, an icon letter above the name.
pub fn menu(b: &mut Batch, flush: Flush) -> Result<Screen, LvError> {
    room(b, flush, 0)?;
    let page = plain_page(b)?;
    let mut s = Screen { kind: Kind::Menu, page, ..EMPTY };
    for (i, sec) in SECTIONS.iter().enumerate() {
        room(b, flush, 0)?;
        let (col, row) = ((i % 2) as i32, (i / 2) as i32);
        let btn = b.create(Class::Btn, page)?;
        b.size(btn, TILE_W, TILE_H)?;
        let x = (col * 2 - 1) * (TILE_W + TILE_GAP) / 2;
        b.align(btn, Align::TopMid, x as i16, (TILE_TOP + row * (TILE_H + TILE_GAP)) as i16)?;
        b.style(btn, Prop::Radius, 0, 28)?;
        b.style(btn, Prop::BgColor, 0, ROW_BG)?;
        b.style(btn, Prop::BgOpa, 0, 255)?;
        b.style(btn, Prop::BgColor, stock::PRESSED, ROW_PRESSED)?;
        b.style(btn, Prop::BgOpa, stock::PRESSED, 255)?;
        let icon = b.create(Class::Label, btn)?;
        b.size(icon, TILE_W - 8, 60)?;
        b.style(icon, Prop::TextAlign, 0, 2)?;
        b.style(icon, Prop::TextFont, 0, F48 as i32)?;
        b.text(icon, sec.icon)?;
        b.align(icon, Align::TopMid, 0, 6)?;
        let name = b.create(Class::Label, btn)?;
        b.size(name, TILE_W - 8, 24)?;
        b.long_mode(name, LongMode::Dot)?;
        b.style(name, Prop::TextAlign, 0, 2)?;
        b.style(name, Prop::TextFont, 0, F18 as i32)?;
        b.text(name, sec.name)?;
        b.align(name, Align::BottomMid, 0, -10)?;
        b.events(btn, &[Ev::Clicked])?;
        s.tiles[i] = btn;
    }
    Ok(s)
}

/// A section: the title (tap: back to the menu), a row per topic, then a "back" row.
pub fn topics(b: &mut Batch, flush: Flush, si: usize) -> Result<Screen, LvError> {
    let sec = &SECTIONS[si.min(COUNT - 1)];
    room(b, flush, 0)?;
    let (page, _bar) = stock::page(b)?;
    let mut s = Screen { kind: Kind::Topics, page, ..EMPTY };
    let title = stock::title(b, page, sec.name)?;
    b.flags(title, &[Flag::Clickable], &[])?;
    b.events(title, &[Ev::Clicked])?;
    s.back = title;
    for (i, t) in sec.topics.iter().enumerate().take(MAX_TOPICS) {
        room(b, flush, 0)?;
        s.rows[i] = stock::row(b, page, &sec.icon[..1], t.name, "")?;
    }
    room(b, flush, 0)?;
    s.back_row = stock::row(b, page, "<", "Назад", "")?;
    Ok(s)
}

/// A stock-looking row with two lines: the formula above, a grey caption under it.
fn two_lines(b: &mut Batch, row: Obj, top: &str, caption: &str) -> Result<(), LvError> {
    let t = b.create(Class::Label, row)?;
    b.size(t, TEXT_W, 40)?;
    b.long_mode(t, LongMode::Dot)?;
    b.style(t, Prop::TextAlign, 0, 1)?; // left
    b.text(t, top)?;
    b.align(t, Align::LeftMid, TEXT_X, -16)?;
    b.flags(t, &[], &[Flag::Clickable, Flag::Scrollable])?;
    let d = b.create(Class::Label, row)?;
    b.size(d, TEXT_W, 30)?;
    b.long_mode(d, LongMode::Dot)?;
    b.style(d, Prop::TextAlign, 0, 1)?;
    b.style(d, Prop::TextFont, 0, F24 as i32)?;
    b.style(d, Prop::TextColor, 0, GREY)?;
    b.text(d, caption)?;
    b.align(d, Align::LeftMid, TEXT_X, 20)?;
    b.flags(d, &[], &[Flag::Clickable, Flag::Scrollable])
}

/// Lines a text of `n` characters takes, never fewer than one.
pub fn lines_for(n: usize) -> usize {
    ((n + CPL - 1) / CPL).max(1)
}

/// One text line: a label that wraps, with room for the lines it can take. "# " starts a grey heading.
fn paragraph(b: &mut Batch, page: Obj, text: &str) -> Result<(), LvError> {
    let (head, body) = match text.strip_prefix("# ") {
        Some(h) => (true, h),
        None => (false, text),
    };
    let l = b.create(Class::Label, page)?;
    let h = lines_for(body.chars().count()) * LINE_H + if head { 12 } else { 8 };
    b.size(l, TEXT_W, h as i32)?;
    b.long_mode(l, LongMode::Wrap)?;
    b.style(l, Prop::TextAlign, 0, 1)?;
    b.style(l, Prop::TextFont, 0, F24 as i32)?;
    if head {
        b.style(l, Prop::TextColor, 0, GREY)?;
    }
    b.text(l, body)?;
    b.flags(l, &[], &[Flag::Clickable, Flag::Scrollable])
}

/// One topic: the title (tap: back to the topics), its cards or lines, then a "back" row.
pub fn topic(b: &mut Batch, flush: Flush, si: usize, ti: usize) -> Result<Screen, LvError> {
    let sec = &SECTIONS[si.min(COUNT - 1)];
    let t = &sec.topics[ti.min(sec.topics.len() - 1)];
    room(b, flush, 0)?;
    let (page, _bar) = stock::page(b)?;
    let mut s = Screen { kind: Kind::Topic, page, ..EMPTY };
    let title = stock::title(b, page, t.name)?;
    b.flags(title, &[Flag::Clickable], &[])?;
    b.events(title, &[Ev::Clicked])?;
    s.back = title;
    match &t.body {
        Body::Rows(rows) => {
            for (formula, caption) in rows.iter() {
                room(b, flush, formula.len() + caption.len())?;
                let row = stock::card(b, page, ROW_H)?;
                b.flags(row, &[], &[Flag::Scrollable])?;
                two_lines(b, row, formula, caption)?;
            }
        }
        Body::Text(lines) => {
            for line in lines.iter() {
                room(b, flush, line.len())?;
                paragraph(b, page, line)?;
            }
        }
    }
    room(b, flush, 0)?;
    s.back_row = stock::row(b, page, "<", "Назад", "")?;
    Ok(s)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tiles_stay_inside_the_round_panel() {
        // the tile grid is centred; its outer corners at the top and bottom rows are the furthest from the middle
        let half = |y: i32| ((233 * 233 - (y - 233) * (y - 233)) as f64).sqrt() as i32;
        let outer = TILE_W + TILE_GAP / 2;
        for y in [TILE_TOP, TILE_TOP + 2 * (TILE_H + TILE_GAP) + TILE_H] {
            assert!(outer <= half(y) + 14, "tile corner out at y={y}"); // the 28 px rounding takes the corner
        }
    }

    #[test]
    fn a_text_takes_whole_lines() {
        assert_eq!(lines_for(0), 1);
        assert_eq!(lines_for(CPL), 1);
        assert_eq!(lines_for(CPL + 1), 2);
    }
}
