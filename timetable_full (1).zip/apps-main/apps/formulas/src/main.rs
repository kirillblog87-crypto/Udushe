//! formulas: a pocket reference on the watch, in the stock LVGL look: a menu of six tiles (physics, algebra,
//! geometry, Russian, literature, history), a section's list of topics and a topic: formula cards or notes
//! (`src/screens.rs`). The text is built in (`src/data.rs`); nothing is stored and no phone is needed. The `device`
//! module is thin.
//!
//! LVGL: the stock widgets come from the system, so the simulator (`make sim`) can't run this app; test it with
//! `make test APP=formulas` and in the emulator (README.md).
#![cfg_attr(target_os = "none", no_std, no_main)]

#[cfg_attr(not(target_os = "none"), allow(dead_code))]
mod data;
#[cfg_attr(not(target_os = "none"), allow(dead_code))]
mod screens;

#[cfg(not(target_os = "none"))]
fn main() {}

#[cfg(target_os = "none")]
mod device {
    use crate::screens::{self, Flush, Kind, Screen};
    use cmf_wp2_app::lv::{Batch, Lv, LvError, StockFont};
    use cmf_wp2_app::{stock, Api, BUTTON, LV};

    cmf_wp2_app::entry!(main);
    cmf_wp2_app::app_icon!();

    /// LVGL 8.3 `LV_EVENT_CLICKED`.
    const CLICKED: i16 = 7;

    /// Deletes the current screen and builds the next one, in one batch.
    fn swap(
        lv: &Lv,
        b: &mut Batch,
        s: &mut Screen,
        make: impl FnOnce(&mut Batch, Flush) -> Result<Screen, LvError>,
    ) -> bool {
        if screens::leave(b, s).is_err() {
            return false;
        }
        let mut flush = |b: &mut Batch| b.submit(lv);
        match make(b, &mut flush) {
            Ok(next) => {
                *s = next;
                b.submit(lv).is_ok()
            }
            Err(_) => false,
        }
    }

    #[derive(Clone, Copy)]
    enum Go {
        Menu,
        Topics(usize),
        Topic(usize, usize),
    }

    fn main(api: &'static Api) -> i32 {
        let Some(lv) = api.lv() else { return -95 }; // loader older than ABI 1.2
        let Some(mut b) = Batch::new() else { return -1 };

        // Each font in a batch of its own: a missing font file stops the batch it is in.
        for (slot, font) in [
            (stock::FONT, stock::SYSTEM_FONT),
            (screens::F48, StockFont::F48M),
            (screens::F18, StockFont::F18M),
            (screens::F24, StockFont::F24M),
        ] {
            if b.font(slot, font).and_then(|_| b.submit(&lv)).is_err() {
                return 1;
            }
        }

        let mut flush = |b: &mut Batch| b.submit(&lv);
        let mut s = match stock::theme(&mut b).and_then(|_| screens::menu(&mut b, &mut flush)) {
            Ok(s) => s,
            Err(_) => return 2,
        };
        if b.submit(&lv).is_err() {
            return 3;
        }

        // the section on screen
        let mut si = 0usize;
        loop {
            let Some(e) = api.event(u32::MAX) else { continue };
            let mut go: Option<Go> = None;
            match e.kind {
                BUTTON => break,
                LV => {
                    let h = e.x as u16;
                    let is = |o: cmf_wp2_app::lv::Obj| h != 0 && o.0 == h;
                    if e.y == CLICKED {
                        match s.kind {
                            Kind::Menu => {
                                if let Some(i) = s.tiles.iter().position(|t| is(*t)) {
                                    si = i;
                                    go = Some(Go::Topics(i));
                                }
                            }
                            Kind::Topics => {
                                if let Some(i) = s.rows.iter().position(|r| is(*r)) {
                                    go = Some(Go::Topic(si, i));
                                } else if is(s.back) || is(s.back_row) {
                                    go = Some(Go::Menu);
                                }
                            }
                            Kind::Topic => {
                                if is(s.back) || is(s.back_row) {
                                    go = Some(Go::Topics(si));
                                }
                            }
                        }
                    }
                }
                _ => {}
            }
            if let Some(g) = go {
                let ok = match g {
                    Go::Menu => swap(&lv, &mut b, &mut s, |b, f| screens::menu(b, f)),
                    Go::Topics(i) => swap(&lv, &mut b, &mut s, |b, f| screens::topics(b, f, i)),
                    Go::Topic(i, j) => swap(&lv, &mut b, &mut s, |b, f| screens::topic(b, f, i, j)),
                };
                if !ok {
                    return 4;
                }
            }
        }
        0
    }
}
