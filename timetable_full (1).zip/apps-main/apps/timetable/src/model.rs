//! Timetable data and time arithmetic. Pure code, no SDK calls: host-tested (`make test APP=timetable`).
//! No heap: lessons live in fixed arrays, text is formatted into caller buffers.

use crate::keys::Text;

/// Lessons per day.
pub const MAX_LESSONS: usize = 10;
/// Monday .. Sunday.
pub const DAYS: usize = 7;
pub const DAY_NAMES: [&str; DAYS] =
    ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];
pub use crate::keys::NAME_MAX;
/// Minutes are chosen in steps of 5.
pub const STEP: u16 = 5;
const LAST_START: u16 = 23 * 60 + 55;

pub const BLOB_MAGIC: [u8; 2] = *b"TT";
pub const BLOB_VERSION: u8 = 2;
/// The first format: one list for every day.
const BLOB_V1: u8 = 1;
const LESSON_BYTES: usize = 2 + 2 + 1 + NAME_MAX;
/// magic, version, then per day a count and its lessons: 3 + 7 * (1 + 10 * 35) = 2460 B of the 4096 B storage.
pub const BLOB_MAX: usize = 3 + DAYS * (1 + MAX_LESSONS * LESSON_BYTES);

#[derive(Clone, Copy)]
pub struct Lesson {
    /// Minutes since midnight.
    pub start: u16,
    pub end: u16,
    name: Text,
}

impl Lesson {
    pub const fn new(start: u16, end: u16, name: Text) -> Self {
        Lesson { start, end, name }
    }
    pub fn name(&self) -> &str {
        self.name.as_str()
    }
}

#[derive(Clone, Copy)]
pub struct Schedule {
    lessons: [Lesson; MAX_LESSONS],
    len: usize,
}

/// What the clock says about the schedule right now.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Now {
    Empty,
    /// In lesson `idx`: seconds left and the lesson's length in seconds.
    Lesson { idx: usize, left_s: u32, total_s: u32 },
    /// Between lessons (or before the first): lesson `idx` is next, in `left_s` seconds.
    Break { idx: usize, left_s: u32 },
    Over,
}

impl Schedule {
    pub const fn new() -> Self {
        Schedule { lessons: [Lesson::new(0, 0, Text::new()); MAX_LESSONS], len: 0 }
    }
    pub fn len(&self) -> usize {
        self.len
    }
    pub fn get(&self, i: usize) -> &Lesson {
        &self.lessons[i.min(MAX_LESSONS - 1)]
    }

    /// Adds or replaces (`idx < len`) a lesson, then keeps the list sorted by start. False when full.
    pub fn put(&mut self, idx: usize, lesson: Lesson) -> bool {
        if idx < self.len {
            self.lessons[idx] = lesson;
        } else if self.len < MAX_LESSONS {
            self.lessons[self.len] = lesson;
            self.len += 1;
        } else {
            return false;
        }
        self.sort();
        true
    }

    pub fn remove(&mut self, idx: usize) {
        if idx >= self.len {
            return;
        }
        for i in idx..self.len - 1 {
            self.lessons[i] = self.lessons[i + 1];
        }
        self.len -= 1;
    }

    fn sort(&mut self) {
        // insertion sort: at most 10 items
        for i in 1..self.len {
            let mut j = i;
            while j > 0 && self.lessons[j - 1].start > self.lessons[j].start {
                self.lessons.swap(j - 1, j);
                j -= 1;
            }
        }
    }

    /// Where a new lesson starts by default: 10 minutes after the last one, 08:30 for the first.
    pub fn next_start(&self) -> u16 {
        if self.len == 0 {
            return 8 * 60 + 30;
        }
        let last = self.lessons[self.len - 1].end;
        (last + 10).min(LAST_START) / STEP * STEP
    }

    pub fn status(&self, now_s: u32) -> Now {
        if self.len == 0 {
            return Now::Empty;
        }
        for i in 0..self.len {
            let (s, e) = (self.lessons[i].start as u32 * 60, self.lessons[i].end as u32 * 60);
            if now_s < s {
                return Now::Break { idx: i, left_s: s - now_s };
            }
            if now_s < e {
                return Now::Lesson { idx: i, left_s: e - now_s, total_s: e - s };
            }
        }
        Now::Over
    }

    /// Writes the count and the lessons at `p`; returns the position after them.
    fn write(&self, out: &mut [u8], mut p: usize) -> usize {
        out[p] = self.len as u8;
        p += 1;
        for l in &self.lessons[..self.len] {
            out[p..p + 2].copy_from_slice(&l.start.to_le_bytes());
            out[p + 2..p + 4].copy_from_slice(&l.end.to_le_bytes());
            let n = l.name.as_str().as_bytes();
            out[p + 4] = n.len() as u8;
            out[p + 5..p + 5 + NAME_MAX].fill(0);
            out[p + 5..p + 5 + n.len()].copy_from_slice(n);
            p += LESSON_BYTES;
        }
        p
    }

    /// Reads a count and its lessons at `*p` and moves `*p` past them. None when the blob is too short.
    fn read(blob: &[u8], p: &mut usize) -> Option<Schedule> {
        let raw = *blob.get(*p)? as usize;
        let n = raw.min(MAX_LESSONS);
        let stop = *p + 1 + raw * LESSON_BYTES;
        if blob.len() < stop {
            return None;
        }
        let mut s = Schedule::new();
        for i in 0..n {
            let q = *p + 1 + i * LESSON_BYTES;
            let start = u16::from_le_bytes([blob[q], blob[q + 1]]);
            let end = u16::from_le_bytes([blob[q + 2], blob[q + 3]]);
            let len = (blob[q + 4] as usize).min(NAME_MAX);
            let mut name = Text::new();
            name.set(core::str::from_utf8(&blob[q + 5..q + 5 + len]).unwrap_or(""));
            if start < end && end <= 24 * 60 {
                s.lessons[s.len] = Lesson::new(start, end, name);
                s.len += 1;
            }
        }
        s.sort();
        *p = stop;
        Some(s)
    }
}

/// The whole week: one schedule per day, Monday first.
#[derive(Clone, Copy)]
pub struct Week {
    pub days: [Schedule; DAYS],
}

impl Week {
    pub const fn new() -> Self {
        Week { days: [Schedule::new(); DAYS] }
    }

    /// Writes the blob for `Api::save`; returns its length.
    pub fn encode(&self, out: &mut [u8; BLOB_MAX]) -> usize {
        out[0..2].copy_from_slice(&BLOB_MAGIC);
        out[2] = BLOB_VERSION;
        let mut p = 3;
        for d in &self.days {
            p = d.write(out, p);
        }
        p
    }

    /// Reads a blob into `self` in place (the week is too big to pass around on the 8 KiB stack); anything
    /// unexpected is "never saved" (an empty week). The old one-list format becomes Monday to Friday.
    pub fn load(&mut self, blob: &[u8]) {
        for d in self.days.iter_mut() {
            *d = Schedule::new();
        }
        if blob.len() < 3 || blob[0..2] != BLOB_MAGIC {
            return;
        }
        let mut p = 3;
        match blob[2] {
            BLOB_V1 => {
                if let Some(s) = Schedule::read(blob, &mut p) {
                    for d in 0..5 {
                        self.days[d] = s;
                    }
                }
            }
            BLOB_VERSION => {
                for d in 0..DAYS {
                    match Schedule::read(blob, &mut p) {
                        Some(s) => self.days[d] = s,
                        None => break,
                    }
                }
            }
            _ => {}
        }
    }

    /// Host tests only: the week from a blob.
    #[cfg(test)]
    pub fn decode(blob: &[u8]) -> Self {
        let mut w = Week::new();
        w.load(blob);
        w
    }
}

/// 0 = Monday .. 6 = Sunday (Sakamoto's method, proleptic Gregorian).
pub fn weekday(year: i32, month: u8, day: u8) -> usize {
    const OFFSETS: [i32; 12] = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4];
    let mut y = year;
    if month < 3 {
        y -= 1;
    }
    let sunday_first =
        (y + y / 4 - y / 100 + y / 400 + OFFSETS[(month as usize).clamp(1, 12) - 1] + day as i32).rem_euclid(7);
    ((sunday_first + 6) % 7) as usize
}

/// Where a lesson of `day` stands on `today` at `now_s` seconds after midnight.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Phase {
    /// In progress: seconds left and the lesson's length.
    Running { left_s: u32, total_s: u32 },
    /// Not started: seconds to the start (a lesson of another day counts the days too).
    Soon { left_s: u32 },
    /// Today's lesson that is over.
    Finished,
}

pub fn phase(l: &Lesson, day: usize, today: usize, now_s: u32) -> Phase {
    let (s, e) = (l.start as u32 * 60, l.end as u32 * 60);
    if day == today {
        if now_s < s {
            Phase::Soon { left_s: s - now_s }
        } else if now_s < e {
            Phase::Running { left_s: e - now_s, total_s: e - s }
        } else {
            Phase::Finished
        }
    } else {
        let days = ((day % DAYS + DAYS - today % DAYS) % DAYS) as u32;
        Phase::Soon { left_s: (days * 86_400 + s).saturating_sub(now_s) }
    }
}

/// A lesson being edited. Hours and minute steps are what the rollers show.
#[derive(Clone, Copy)]
pub struct Edit {
    /// `idx >= schedule.len()`: a new lesson.
    pub idx: usize,
    pub sh: u8,
    pub sm: u8,
    pub eh: u8,
    pub em: u8,
    pub name: Text,
}

impl Edit {
    pub fn from_lesson(idx: usize, l: &Lesson) -> Self {
        Edit { idx, sh: (l.start / 60) as u8, sm: (l.start % 60 / STEP) as u8, eh: (l.end / 60) as u8,
               em: (l.end % 60 / STEP) as u8, name: l.name }
    }
    pub fn new_lesson(sch: &Schedule) -> Self {
        let start = sch.next_start();
        let end = (start + 40).min(23 * 60 + 55);
        Edit::from_lesson(sch.len(), &Lesson::new(start, end, Text::new()))
    }
    pub fn start(&self) -> u16 {
        self.sh as u16 * 60 + self.sm as u16 * STEP
    }
    pub fn end(&self) -> u16 {
        self.eh as u16 * 60 + self.em as u16 * STEP
    }
    /// The lesson to store. An end that is not after the start becomes start + 40 minutes.
    pub fn to_lesson(&self) -> Lesson {
        let start = self.start();
        let mut end = self.end();
        if end <= start {
            end = (start + 40).min(24 * 60);
        }
        Lesson::new(start, end, self.name)
    }
}

fn put_str(buf: &mut [u8], at: usize, s: &str) -> usize {
    let b = s.as_bytes();
    buf[at..at + b.len()].copy_from_slice(b);
    at + b.len()
}

fn two(buf: &mut [u8], at: usize, v: u32) {
    buf[at] = b'0' + (v / 10 % 10) as u8;
    buf[at + 1] = b'0' + (v % 10) as u8;
}

fn as_str(buf: &[u8]) -> &str {
    core::str::from_utf8(buf).unwrap_or("")
}

/// `HH:MM` from minutes since midnight.
pub fn hhmm(min: u16, buf: &mut [u8; 5]) -> &str {
    two(buf, 0, (min / 60) as u32);
    buf[2] = b':';
    two(buf, 3, (min % 60) as u32);
    as_str(buf)
}

/// `HH:MM-HH:MM`.
pub fn range(a: u16, b: u16, buf: &mut [u8; 11]) -> &str {
    two(buf, 0, (a / 60) as u32);
    buf[2] = b':';
    two(buf, 3, (a % 60) as u32);
    buf[5] = b'-';
    two(buf, 6, (b / 60) as u32);
    buf[8] = b':';
    two(buf, 9, (b % 60) as u32);
    as_str(buf)
}

/// `1`..`99`.
pub fn number(n: usize, buf: &mut [u8; 3]) -> &str {
    let n = n.clamp(0, 99) as u32;
    if n < 10 {
        buf[0] = b'0' + n as u8;
        as_str(&buf[..1])
    } else {
        two(buf, 0, n);
        as_str(&buf[..2])
    }
}

/// The lesson's name, or "Предмет N" while it has none.
pub fn display_name<'a>(l: &'a Lesson, i: usize, buf: &'a mut [u8; 40]) -> &'a str {
    if !l.name().is_empty() {
        return l.name();
    }
    let mut p = put_str(buf, 0, "Предмет ");
    let mut n = [0u8; 3];
    p = put_str(buf, p, number(i + 1, &mut n));
    as_str(&buf[..p])
}

/// `MM:SS`, or `H:MM:SS` from one hour (the hours can have three digits for a lesson days away).
pub fn countdown(secs: u32, buf: &mut [u8; 12]) -> &str {
    let (h, m, s) = (secs / 3600, secs / 60 % 60, secs % 60);
    let mut p = 0;
    if h > 0 {
        if h >= 100 {
            buf[p] = b'0' + (h / 100 % 10) as u8;
            p += 1;
        }
        if h >= 10 {
            buf[p] = b'0' + (h / 10 % 10) as u8;
            p += 1;
        }
        buf[p] = b'0' + (h % 10) as u8;
        buf[p + 1] = b':';
        p += 2;
    }
    two(buf, p, m);
    buf[p + 2] = b':';
    two(buf, p + 3, s);
    as_str(&buf[..p + 5])
}

/// `<day> HH:MM-HH:MM`.
pub fn day_range<'a>(day: usize, from: u16, to: u16, buf: &'a mut [u8; 48]) -> &'a str {
    let mut p = put_str(buf, 0, DAY_NAMES[day.min(DAYS - 1)]);
    buf[p] = b' ';
    p += 1;
    let mut r = [0u8; 11];
    p = put_str(buf, p, range(from, to, &mut r));
    as_str(&buf[..p])
}

/// `<name> - до HH:MM` (`prefix` "до") or `<name> - в HH:MM`.
pub fn line<'a>(name: &str, prefix: &str, min: u16, buf: &'a mut [u8; 64]) -> &'a str {
    let mut p = put_str(buf, 0, name);
    p = put_str(buf, p, " - ");
    p = put_str(buf, p, prefix);
    buf[p] = b' ';
    p += 1;
    let mut t = [0u8; 5];
    p = put_str(buf, p, hhmm(min, &mut t));
    as_str(&buf[..p])
}

/// `СЕЙЧАС HH:MM`.
pub fn clock(min: u16, buf: &mut [u8; 24]) -> &str {
    let mut p = put_str(buf, 0, "СЕЙЧАС ");
    let mut t = [0u8; 5];
    p = put_str(buf, p, hhmm(min, &mut t));
    as_str(&buf[..p])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lesson(s: u16, e: u16, name: &str) -> Lesson {
        let mut t = Text::new();
        t.set(name);
        Lesson::new(s, e, t)
    }

    #[test]
    fn status_walks_through_the_day() {
        let mut s = Schedule::new();
        assert_eq!(s.status(0), Now::Empty);
        s.put(0, lesson(9 * 60, 9 * 60 + 40, "A"));
        s.put(1, lesson(9 * 60 + 50, 10 * 60 + 30, "B"));
        assert_eq!(s.status(8 * 3600), Now::Break { idx: 0, left_s: 3600 });
        assert_eq!(s.status(9 * 3600 + 600), Now::Lesson { idx: 0, left_s: 1800, total_s: 2400 });
        assert_eq!(s.status(9 * 3600 + 2400), Now::Break { idx: 1, left_s: 600 });
        assert_eq!(s.status(11 * 3600), Now::Over);
    }

    #[test]
    fn put_sorts_and_remove_closes_the_gap() {
        let mut s = Schedule::new();
        s.put(0, lesson(600, 640, "late"));
        s.put(1, lesson(500, 540, "early"));
        assert_eq!(s.get(0).name(), "early");
        s.remove(0);
        assert_eq!((s.len(), s.get(0).name()), (1, "late"));
    }

    #[test]
    fn blob_round_trips_cyrillic_names_per_day() {
        let mut w = Week::new();
        w.days[0].put(0, lesson(510, 550, "Математика"));
        w.days[0].put(1, lesson(560, 600, ""));
        w.days[6].put(0, lesson(700, 740, "Физика"));
        let mut blob = [0u8; BLOB_MAX];
        let n = w.encode(&mut blob);
        let d = Week::decode(&blob[..n]);
        assert_eq!(d.days[0].len(), 2);
        assert_eq!(d.days[0].get(0).name(), "Математика");
        assert_eq!((d.days[0].get(1).start, d.days[0].get(1).end), (560, 600));
        assert_eq!(d.days[1].len(), 0);
        assert_eq!(d.days[6].get(0).name(), "Физика");
        assert_eq!(Week::decode(b"xx").days[0].len(), 0);
    }

    #[test]
    fn the_old_blob_becomes_monday_to_friday() {
        let mut old = [0u8; 4 + LESSON_BYTES];
        old[0..2].copy_from_slice(&BLOB_MAGIC);
        old[2] = 1;
        old[3] = 1;
        old[4..6].copy_from_slice(&540u16.to_le_bytes());
        old[6..8].copy_from_slice(&580u16.to_le_bytes());
        old[8] = 2;
        old[9..11].copy_from_slice(b"Al");
        let w = Week::decode(&old);
        assert_eq!(w.days[0].get(0).name(), "Al");
        assert_eq!(w.days[4].len(), 1);
        assert_eq!(w.days[5].len(), 0);
    }

    #[test]
    fn weekdays_start_on_monday() {
        assert_eq!(weekday(2026, 11, 16), 0);
        assert_eq!(weekday(2026, 11, 26), 3);
        assert_eq!(weekday(2026, 11, 29), 6);
        assert_eq!(weekday(2024, 2, 29), 3);
    }

    #[test]
    fn phase_counts_to_the_end_to_the_start_or_to_another_day() {
        let l = lesson(9 * 60, 9 * 60 + 40, "A");
        assert_eq!(phase(&l, 2, 2, 8 * 3600), Phase::Soon { left_s: 3600 });
        assert_eq!(phase(&l, 2, 2, 9 * 3600 + 600), Phase::Running { left_s: 1800, total_s: 2400 });
        assert_eq!(phase(&l, 2, 2, 10 * 3600), Phase::Finished);
        // Tuesday's lesson seen on Monday at 08:00: a day and an hour
        assert_eq!(phase(&l, 1, 0, 8 * 3600), Phase::Soon { left_s: 86_400 + 3600 });
        // Monday's lesson seen on Wednesday: next Monday
        assert_eq!(phase(&l, 0, 2, 9 * 3600), Phase::Soon { left_s: 5 * 86_400 });
    }

    #[test]
    fn formatting() {
        let (mut a, mut b, mut c) = ([0u8; 5], [0u8; 11], [0u8; 12]);
        assert_eq!(hhmm(9 * 60 + 5, &mut a), "09:05");
        assert_eq!(range(585, 625, &mut b), "09:45-10:25");
        assert_eq!(countdown(75, &mut c), "01:15");
        assert_eq!(countdown(3725, &mut c), "1:02:05");
        assert_eq!(countdown(100 * 3600 + 61, &mut c), "100:01:01");
        let mut d = [0u8; 48];
        assert_eq!(day_range(1, 585, 625, &mut d), "Вторник 09:45-10:25");
        let l = lesson(0, 1, "");
        let mut n = [0u8; 40];
        assert_eq!(display_name(&l, 2, &mut n), "Предмет 3");
    }

    #[test]
    fn new_lesson_starts_after_the_last_and_end_is_after_start() {
        let mut s = Schedule::new();
        assert_eq!(s.next_start(), 8 * 60 + 30);
        s.put(0, lesson(510, 550, "A"));
        assert_eq!(s.next_start(), 560);
        let mut e = Edit::new_lesson(&s);
        e.eh = e.sh;
        e.em = e.sm;
        let l = e.to_lesson();
        assert!(l.end > l.start);
    }
}
