//! timetable: a bell schedule on the watch, in the stock LVGL look of the "Расписание" video.
//!
//! Screens (`src/screens.rs`): the list of lessons of one day of the week (tap the day row to switch the day; tap a
//! lesson to see the time left to its end or its start); the editor (name row, start and end set by swiping hour and
//! minute rollers, minutes in steps of 5); the on-watch keyboard (Russian letters, digits) for the name; and
//! "Сейчас", the countdown to the end of the lesson or to the break. The lessons are kept in the app's storage blob
//! (`src/model.rs`, 2460 B at most: seven days of ten lessons). Pure logic (`model`, `keys`) has host tests; the `device` module below is thin.
//!
//! LVGL: the stock widgets (focus of rows, rollers, pills) come from the system, so the simulator (`make sim`) can't
//! run this app; test it with `make test APP=timetable` and in the emulator (README.md).
#![cfg_attr(target_os = "none", no_std, no_main)]

#[cfg_attr(not(target_os = "none"), allow(dead_code))]
mod keys;
#[cfg_attr(not(target_os = "none"), allow(dead_code))]
mod model;
#[cfg_attr(not(target_os = "none"), allow(dead_code))]
mod screens;

#[cfg(not(target_os = "none"))]
fn main() {}

#[cfg(target_os = "none")]
mod device {
    use crate::keys;
    use crate::model::{self, Edit, Now, Phase, Week, BLOB_MAX, DAYS};
    use crate::screens::{self, Flush, Kind, Screen};
    use cmf_wp2_app::lv::{Batch, Lv, LvError, StockFont};
    use cmf_wp2_app::{stock, Api, BUTTON, LV, RESUME};

    cmf_wp2_app::entry!(main);
    cmf_wp2_app::app_icon!();

    /// LVGL 8.3 `LV_EVENT_CLICKED` and `LV_EVENT_VALUE_CHANGED`.
    const CLICKED: i16 = 7;
    const VALUE_CHANGED: i16 = 28;

    // ponytail: the week (3 KB) and its blob (2.5 KB) do not fit the 8 KiB stack
    static mut STORE: [u8; BLOB_MAX] = [0; BLOB_MAX];
    static mut WEEK: Week = Week::new();

    fn load(api: &Api, w: &mut Week) {
        let blob = unsafe { &mut *core::ptr::addr_of_mut!(STORE) };
        let n = api.load(&mut blob[..]);
        if n > 0 {
            w.load(&blob[..(n as usize).min(BLOB_MAX)]);
        }
    }

    fn save(api: &Api, w: &Week) {
        let blob = unsafe { &mut *core::ptr::addr_of_mut!(STORE) };
        let n = w.encode(blob);
        api.save(&blob[..n]);
    }

    /// Today's day of the week (0 = Monday) and the seconds since midnight.
    fn clock(api: &Api) -> Option<(usize, u32)> {
        api.time().map(|t| {
            let day = model::weekday(t.year as i32, t.month as u8, t.day as u8);
            (day, t.hour as u32 * 3600 + t.minute as u32 * 60 + t.second as u32)
        })
    }

    /// Deletes the current screen and builds the next one, in one batch.
    fn swap(
        lv: &Lv,
        b: &mut Batch,
        s: &mut Screen,
        make: impl FnOnce(&mut Batch, Flush) -> Result<Screen, LvError>,
    ) -> bool {
        if screens::leave(b, s).is_err() {
            return false;
        }
        let mut flush = |b: &mut Batch| b.submit(lv);
        match make(b, &mut flush) {
            Ok(next) => {
                *s = next;
                b.submit(lv).is_ok()
            }
            Err(_) => false,
        }
    }

    /// The "now" screen's texts for the wall clock: today's lessons.
    fn draw_now(api: &Api, b: &mut Batch, lv: &Lv, s: &Screen, week: &Week) -> bool {
        let Some((today, t)) = clock(api) else { return false };
        let sch = &week.days[today];
        let (mut cb, mut kb, mut nb, mut lb) = ([0u8; 12], [0u8; 24], [0u8; 40], [0u8; 64]);
        let clock = model::clock((t / 60) as u16, &mut kb);
        let (head, sub, time, bar, line) = match sch.status(t) {
            Now::Empty => ("НЕТ УРОКОВ", "ДОБАВЬ ИХ В СПИСКЕ", "--:--", 0, ""),
            Now::Over => ("ВСЁ НА СЕГОДНЯ", "", "--:--", 100, ""),
            Now::Lesson { idx, left_s, total_s } => {
                let l = sch.get(idx);
                let name = model::display_name(l, idx, &mut nb);
                let used = 100 - (left_s as u64 * 100 / total_s.max(1) as u64) as i32;
                ("СЕЙЧАС УРОК", "ДО КОНЦА УРОКА", model::countdown(left_s, &mut cb), used,
                 model::line(name, "до", l.end, &mut lb))
            }
            Now::Break { idx, left_s } => {
                let l = sch.get(idx);
                let name = model::display_name(l, idx, &mut nb);
                (if idx == 0 { "ДО УРОКОВ" } else { "ПЕРЕМЕНА" }, "ДО НАЧАЛА УРОКА",
                 model::countdown(left_s, &mut cb), 0, model::line(name, "в", l.start, &mut lb))
            }
        };
        screens::now_draw(b, s, head, sub, time, bar, line, clock).and_then(|_| b.submit(lv)).is_ok()
    }

    /// The lesson screen's texts: lesson `sel` of `day`, and how long to its end or its start.
    fn draw_detail(api: &Api, b: &mut Batch, lv: &Lv, s: &Screen, week: &Week, day: usize, sel: usize) -> bool {
        let Some((today, t)) = clock(api) else { return false };
        let sch = &week.days[day];
        if sel >= sch.len() {
            return false;
        }
        let l = sch.get(sel);
        let (mut cb, mut nb, mut db) = ([0u8; 12], [0u8; 40], [0u8; 48]);
        let name = model::display_name(l, sel, &mut nb);
        let when = model::day_range(day, l.start, l.end, &mut db);
        let (caption, time, bar) = match model::phase(l, day, today, t) {
            Phase::Running { left_s, total_s } => {
                let used = 100 - (left_s as u64 * 100 / total_s.max(1) as u64) as i32;
                ("ДО КОНЦА УРОКА", model::countdown(left_s, &mut cb), used)
            }
            Phase::Soon { left_s } => ("ДО НАЧАЛА УРОКА", model::countdown(left_s, &mut cb), 0),
            Phase::Finished => ("УРОК УЖЕ ЗАКОНЧИЛСЯ", "--:--", 100),
        };
        screens::detail_draw(b, s, name, when, caption, time, bar).and_then(|_| b.submit(lv)).is_ok()
    }

    #[derive(Clone, Copy)]
    enum Go {
        List,
        Detail,
        Editor,
        Keyboard,
        Now,
    }

    fn main(api: &'static Api) -> i32 {
        let Some(lv) = api.lv() else { return -95 }; // loader older than ABI 1.2
        let Some(mut b) = Batch::new() else { return -1 };

        // Each font in a batch of its own: a missing font file stops the batch it is in.
        for (slot, font) in [
            (stock::FONT, stock::SYSTEM_FONT),
            (screens::F48, StockFont::F48M),
            (screens::F18, StockFont::F18M),
            (screens::F24, StockFont::F24M),
        ] {
            if b.font(slot, font).and_then(|_| b.submit(&lv)).is_err() {
                return 1;
            }
        }

        let week: &mut Week = unsafe { &mut *core::ptr::addr_of_mut!(WEEK) };
        load(api, week);
        // the day on the list: today, until the day row is tapped
        let mut day = clock(api).map_or(0, |c| c.0).min(DAYS - 1);
        let mut sel = 0usize;
        let mut flush = |b: &mut Batch| b.submit(&lv);
        let today = clock(api).map(|c| c.0);
        let mut s = match stock::theme(&mut b).and_then(|_| screens::list(&mut b, &mut flush, &week.days[day], day, today)) {
            Ok(s) => s,
            Err(_) => return 2,
        };
        if b.submit(&lv).is_err() {
            return 3;
        }

        let mut ed = Edit::new_lesson(&week.days[day]);
        let mut digits = false;

        loop {
            let ticking = matches!(s.kind, Kind::Now | Kind::Detail);
            let timeout = if ticking { 1000 } else { u32::MAX };
            let Some(e) = api.event(timeout) else {
                if s.kind == Kind::Now {
                    draw_now(api, &mut b, &lv, &s, &week);
                } else if s.kind == Kind::Detail {
                    draw_detail(api, &mut b, &lv, &s, &week, day, sel);
                }
                continue;
            };
            let mut go: Option<Go> = None;
            match e.kind {
                BUTTON => break,
                RESUME => {
                    if s.kind == Kind::Now {
                        draw_now(api, &mut b, &lv, &s, &week);
                    } else if s.kind == Kind::Detail {
                        draw_detail(api, &mut b, &lv, &s, &week, day, sel);
                    }
                }
                LV => {
                    let h = e.x as u16;
                    let is = |o: cmf_wp2_app::lv::Obj| h != 0 && o.0 == h;
                    if e.y == CLICKED {
                        match s.kind {
                            Kind::List => {
                                if let Some(i) = s.rows.iter().position(|r| is(*r)) {
                                    sel = i;
                                    go = Some(Go::Detail);
                                } else if is(s.day_row) {
                                    day = (day + 1) % DAYS;
                                    go = Some(Go::List);
                                } else if is(s.add) {
                                    ed = Edit::new_lesson(&week.days[day]);
                                    go = Some(Go::Editor);
                                } else if is(s.fab) {
                                    go = Some(Go::Now);
                                }
                            }
                            Kind::Detail => {
                                if is(s.back) {
                                    go = Some(Go::List);
                                } else if is(s.edit) && sel < week.days[day].len() {
                                    ed = Edit::from_lesson(sel, week.days[day].get(sel));
                                    go = Some(Go::Editor);
                                }
                            }
                            Kind::Editor => {
                                if is(s.back) {
                                    go = Some(Go::List);
                                } else if is(s.name_row) {
                                    digits = false;
                                    go = Some(Go::Keyboard);
                                } else if is(s.done) {
                                    week.days[day].put(ed.idx, ed.to_lesson());
                                    save(api, &week);
                                    go = Some(Go::List);
                                } else if is(s.delete) {
                                    week.days[day].remove(ed.idx);
                                    save(api, &week);
                                    go = Some(Go::List);
                                }
                            }
                            Kind::Keyboard => {
                                let mut changed = false;
                                if let Some(i) = s.keys.iter().position(|k| is(*k)) {
                                    let label = keys::label(digits, i);
                                    changed = !label.is_empty() && ed.name.press(label);
                                } else if is(s.bksp) {
                                    changed = ed.name.backspace();
                                } else if is(s.space) {
                                    changed = ed.name.space();
                                } else if is(s.mode) {
                                    digits = !digits;
                                    let _ = screens::set_mode(&mut b, &s, digits).and_then(|_| b.submit(&lv));
                                } else if is(s.done) {
                                    go = Some(Go::Editor);
                                }
                                if changed {
                                    let _ = screens::set_text(&mut b, &s, ed.name.as_str()).and_then(|_| b.submit(&lv));
                                }
                            }
                            Kind::Now => {
                                if is(s.back) {
                                    go = Some(Go::List);
                                }
                            }
                        }
                    } else if e.y == VALUE_CHANGED && s.kind == Kind::Editor {
                        if let Some(k) = s.rollers.iter().position(|r| is(*r)) {
                            let v = e.delta as u8;
                            match k {
                                0 => ed.sh = v.min(23),
                                1 => ed.sm = v.min(11),
                                2 => ed.eh = v.min(23),
                                _ => ed.em = v.min(11),
                            }
                        }
                    }
                }
                _ => {}
            }

            if let Some(go) = go {
                let ok = match go {
                    Go::List => {
                        let today = clock(api).map(|c| c.0);
                        swap(&lv, &mut b, &mut s, |b, f| screens::list(b, f, &week.days[day], day, today))
                    }
                    Go::Detail => {
                        swap(&lv, &mut b, &mut s, |b, f| screens::detail(b, f))
                            && draw_detail(api, &mut b, &lv, &s, &week, day, sel)
                    }
                    Go::Editor => {
                        let existing = ed.idx < week.days[day].len();
                        swap(&lv, &mut b, &mut s, |b, f| screens::editor(b, f, &ed, existing))
                    }
                    Go::Keyboard => {
                        swap(&lv, &mut b, &mut s, |b, f| screens::keyboard(b, f, ed.name.as_str(), digits))
                    }
                    Go::Now => {
                        swap(&lv, &mut b, &mut s, |b, f| screens::now(b, f))
                            && draw_now(api, &mut b, &lv, &s, &week)
                    }
                };
                if !ok {
                    save(api, &week);
                    return 4;
                }
            }
        }

        save(api, &week);
        0
    }
}
