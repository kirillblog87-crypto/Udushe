A bell schedule for school or university. Each day of the week has its own lessons: tap the day row to switch the day. Add lessons, type a name on the watch's own keyboard (Russian letters and digits), set the start and the end by swiping the hours and the minutes (minutes in steps of 5), tap a lesson to see how long is left to its end or its start, and open **Now** to see the countdown to the end of the lesson or to the break.

The lessons live in the app's 4 KiB storage on the watch. Nothing is sent to a phone.

## Requirements

The [patched firmware](/firmware) and the [App Loader](/firmware). Open it from the **Apps** row at the end of the watch's app list (list style, not the waterfall).
